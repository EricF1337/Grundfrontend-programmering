 const taskInput = document.getElementById('taskInput');
const addButton = document.getElementById('addButton');
const taskList = document.getElementById('taskList');
const searchInput = document.getElementById('searchInput');

// Ladda uppgifter från localStorage
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

// Rendera uppgifter
function renderTasks(filter = '') {
    taskList.innerHTML = '';
    tasks
        .filter(task => task.toLowerCase().includes(filter.toLowerCase()))
        .forEach((task, index) => {
            const li = document.createElement('li');
            li.classList.add('task-item'); // Lägg till klass för styling
            li.textContent = task;

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Ta bort';
            deleteButton.addEventListener('click', () => {
                tasks.splice(index, 1);
                localStorage.setItem('tasks', JSON.stringify(tasks));
                renderTasks(searchInput.value); // Rendera om med aktuell sökning
            });

            li.appendChild(deleteButton);
            taskList.appendChild(li);
        });
}

// Lägg till uppgift
addButton.addEventListener('click', () => {
    const taskText = taskInput.value.trim();
    if (taskText) {
        tasks.push(taskText);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        taskInput.value = '';
        renderTasks(searchInput.value); // Rendera om med aktuell sökning
    }
});

// Sökfunktionalitet
searchInput.addEventListener('input', () => {
    renderTasks(searchInput.value); // Rendera om med aktuell sökning
});

// Initial render
renderTasks();
